下列函数由互操作模块定义：
* `popFloat() -> Number`
  以小数形式读取最早的数字
* `popInt() -> Number`
  以有符号整数形式读取最早的数字
* `pushNumber(Number)`
  压入一个数字（会自动确定有无符号以及是否为浮点数）
  